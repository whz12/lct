<?php exit();?>{"expire_time":1460644088,"jsapi_ticket":"sM4AOVdWfPE4DxkXGEs8VNu9pBMrd96BFmPfMlu8o3UMrsrczcPykQ4E0HVTZGfnKUjKl8n-8dDLso-RbBg2jQ"}
