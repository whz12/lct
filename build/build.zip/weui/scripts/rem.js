document.documentElement.style.fontSize = document.documentElement.clientWidth / 100 * 31.25 + 'px';
